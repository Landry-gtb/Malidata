from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from dotenv import load_dotenv
import os

# Charger variables d'environnement depuis .env
load_dotenv()

# Importer les routers (imports corrigés, sans "backend.")
from backend.routers import chat, rag, reports

# Créer l'application FastAPI
app = FastAPI(
    title="Malidata Chatbot",
    description="Chatbot médical de pré-consultation malaria (⚠️ pré-diagnostic interdit).",
    version="1.0.0"
)

# Configurer CORS pour autoriser frontend (React/Vite)
origins = [
    os.getenv("FRONTEND_URL", "http://localhost:5173"),
    "http://localhost:3000",
    "http://127.0.0.1:5173",
]
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Monter les routers
app.include_router(chat.router, prefix="/api/chat", tags=["chat"])
app.include_router(rag.router, prefix="/api", tags=["rag"])
app.include_router(reports.router, prefix="/api/reports", tags=["reports"])

# Endpoint de santé (healthcheck)
@app.get("/")
def root():
    return {
        "message": "Malidata Chatbot backend is running 🚀",
        "version": "1.0.0",
        "frontend_allowed": origins
    }

