import os
import logging
from dotenv import load_dotenv

# Embeddings HuggingFace
try:
    from langchain_huggingface import HuggingFaceEmbeddings
except ImportError:
    raise ImportError(
        "Le package `langchain-huggingface` est requis.\n"
        "➡️ Installe-le avec : pip install -U langchain-huggingface"
    )

# Vector store FAISS
from langchain_community.vectorstores import FAISS

# 🔥 NOUVEAU : Utilisation de LangChain pour Gemini (pas google.generativeai)
from langchain_google_genai import ChatGoogleGenerativeAI

# Charger variables d'environnement
load_dotenv()

# === CONFIG ===
GEMINI_MODEL = os.getenv("GEMINI_MODEL", "gemini-1.5-flash")  # ✅ Corrigé
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY")
if not GEMINI_API_KEY:
    raise RuntimeError("❌ Clé API Gemini manquante. Ajoute GEMINI_API_KEY dans ton fichier .env")

VECTOR_STORE_PATH = os.getenv(
    "VECTOR_STORE_PATH",
    os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "rag", "vector_store")
)
RAG_TOP_K = int(os.getenv("RAG_TOP_K", 3))
MAX_CONTEXT_CHARS = int(os.getenv("RAG_MAX_CONTEXT_CHARS", 2000))

# Logs
logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger(__name__)

# === Initialisation Embeddings + Vector Store ===
embeddings = HuggingFaceEmbeddings(model_name="sentence-transformers/all-MiniLM-L6-v2")

vector_store = None
try:
    if os.path.exists(VECTOR_STORE_PATH):
        vector_store = FAISS.load_local(
            VECTOR_STORE_PATH,
            embeddings,
            allow_dangerous_deserialization=True
        )
        logger.info(f"✅ Vector store chargé depuis : {VECTOR_STORE_PATH}")
    else:
        logger.warning(f"⚠️ Aucun vector store trouvé dans {VECTOR_STORE_PATH}. Exécute `build_vector_store.py`.")
except Exception as e:
    logger.error(f"❌ Impossible de charger FAISS : {e}")
    vector_store = None

# === Initialisation du LLM via LangChain ===
llm = ChatGoogleGenerativeAI(
    model=GEMINI_MODEL,
    api_key=GEMINI_API_KEY,  # ✅ Nouvelle syntaxe (>=2.0)
    temperature=0.3,
    max_output_tokens=512,
)

# === Fonctions principales ===
def _get_context(query: str, top_k: int = None) -> str:
    """Récupère un contexte textuel depuis le vector store OMS."""
    if not vector_store:
        logger.warning("⚠️ Vector store non disponible, pas de contexte ajouté.")
        return ""

    try:
        k = top_k or RAG_TOP_K
        docs = vector_store.similarity_search(query, k=k)
        if not docs:
            return ""

        unique_texts = list(dict.fromkeys([d.page_content.strip() for d in docs]))
        context = "\n".join(unique_texts).strip()

        if len(context) > MAX_CONTEXT_CHARS:
            logger.warning(f"⚠️ Contexte tronqué à {MAX_CONTEXT_CHARS} caractères.")
            context = context[:MAX_CONTEXT_CHARS]

        return context
    except Exception as e:
        logger.error(f"Erreur dans _get_context: {e}")
        return ""


def rag_search(user_query: str) -> dict:
    """
    Combine contexte RAG + LLM via LangChain.
    Retourne {context, clarification}.
    """
    context = _get_context(user_query)

    try:
        # Prompt sécurisé (anti-diagnostic)
        prompt = (
            f"Voici des extraits de documents officiels de l’OMS sur le paludisme :\n{context}\n\n"
            f"Question du patient : {user_query}\n\n"
            f"👉 Réponds de manière claire et concise, uniquement en français.\n"
            f"👉 Utilise le contexte fourni si pertinent.\n"
            f"👉 Ne donne JAMAIS de diagnostic médical.\n"
            f"👉 Si la question sort du cadre du paludisme, répond poliment que tu n’as pas l’information."
        )

        # Appel via LangChain (pas google.generativeai)
        response = llm.invoke(prompt)
        clarification = response.content.strip() if response.content else "Pas de clarification générée."

        return {
            "context": context or "Pas de contexte ajouté",
            "clarification": clarification
        }

    except Exception as e:
        logger.error(f"Erreur dans rag_search avec LangChain/Gemini: {e}")
        return {
            "context": context or "Pas de contexte ajouté",
            "clarification": "Erreur lors de la génération de la clarification."
        }


# === Test manuel ===
if __name__ == "__main__":
    q = "Quels sont les symptômes graves du paludisme ?"
    res = rag_search(q)
    print("🔍 Contexte récupéré :")
    print(res["context"])
    print("\n💡 Clarification générée :")
    print(res["clarification"])