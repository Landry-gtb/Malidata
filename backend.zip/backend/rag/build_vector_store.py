#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
build_vector_store.py

Pipeline pour construire un vector store FAISS à partir des PDF OMS.
- Extraction PDF
- Découpage en chunks
- Embeddings HuggingFace
- Sauvegarde FAISS + métadonnées

Usage:
    python build_vector_store.py --data_dir data/ --output_dir backend/rag/vector_store
"""

import os
import sys
import json
import logging
import argparse
from pathlib import Path
from datetime import datetime
from typing import List

from tqdm import tqdm
from langchain_community.document_loaders import PyPDFLoader
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_community.embeddings import HuggingFaceEmbeddings
from langchain_community.vectorstores import FAISS
from langchain.schema import Document
from langdetect import detect
import hashlib

# Logger
logging.basicConfig(
    level="INFO",
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[logging.StreamHandler(sys.stdout)]
)
logger = logging.getLogger("build_vector_store")


# --- Helpers ---
def compute_chunk_id(source: str, page: int, idx: int) -> str:
    base = f"{source}:{page}:{idx}"
    return hashlib.sha1(base.encode("utf-8")).hexdigest()[:16]


def detect_language_safe(text: str) -> str:
    try:
        return detect(text)
    except Exception:
        return "unknown"


def extract_documents(pdf_path: Path) -> List[Document]:
    loader = PyPDFLoader(str(pdf_path))
    docs = loader.load()
    for d in docs:
        d.metadata.setdefault("source", pdf_path.name)
    return docs


# --- Pipeline ---
def build_vector_store(data_dir: str, output_dir: str, model_name: str, chunk_size: int, chunk_overlap: int):
    data_path = Path(data_dir)
    output_path = Path(output_dir)

    pdfs = sorted([p for p in data_path.glob("*.pdf")])
    if not pdfs:
        raise FileNotFoundError(f"Aucun PDF trouvé dans {data_path}")

    logger.info(f"{len(pdfs)} PDF(s) trouvés dans {data_path}")

    all_docs = []
    for pdf in tqdm(pdfs, desc="Chargement PDFs"):
        docs = extract_documents(pdf)
        all_docs.extend(docs)

    splitter = RecursiveCharacterTextSplitter(chunk_size=chunk_size, chunk_overlap=chunk_overlap)
    chunks = splitter.split_documents(all_docs)
    logger.info(f"{len(chunks)} chunks créés")

    enriched_chunks = []
    for idx, doc in enumerate(chunks):
        text = doc.page_content.strip()
        src = doc.metadata.get("source", "unknown")
        page = doc.metadata.get("page", None)
        chunk_id = compute_chunk_id(src, page or 0, idx)

        metadata = dict(doc.metadata)
        metadata.update({
            "chunk_id": chunk_id,
            "language": detect_language_safe(text),
            "length": len(text),
            "created_at": datetime.utcnow().isoformat()
        })

        enriched_chunks.append(Document(page_content=text, metadata=metadata))

    embeddings = HuggingFaceEmbeddings(model_name=model_name)
    vectorstore = FAISS.from_documents(enriched_chunks, embeddings)

    output_path.mkdir(parents=True, exist_ok=True)
    vectorstore.save_local(str(output_path))
    logger.info(f"Vector store FAISS sauvegardé dans {output_path}")

    metadata_path = output_path / "metadata.jsonl"
    with open(metadata_path, "w", encoding="utf-8") as f:
        for d in enriched_chunks:
            f.write(json.dumps(d.metadata, ensure_ascii=False) + "\n")

    logger.info(f"Métadonnées sauvegardées dans {metadata_path}")


# --- CLI ---
if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Build FAISS vector store from PDFs")
    parser.add_argument("--data_dir", type=str, default="data", help="Répertoire avec les PDFs")
    parser.add_argument("--output_dir", type=str, default="backend/rag/vector_store", help="Dossier de sortie du FAISS")
    parser.add_argument("--model_name", type=str, default="sentence-transformers/all-MiniLM-L6-v2", help="Modèle HF pour embeddings")
    parser.add_argument("--chunk_size", type=int, default=1000, help="Taille des chunks")
    parser.add_argument("--chunk_overlap", type=int, default=200, help="Overlap des chunks")

    args = parser.parse_args()

    build_vector_store(args.data_dir, args.output_dir, args.model_name, args.chunk_size, args.chunk_overlap)
