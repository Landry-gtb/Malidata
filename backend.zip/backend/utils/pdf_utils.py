# backend/utils/pdf_utils.py
import os
import logging
from datetime import datetime
from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.platypus import Paragraph, Spacer
from reportlab.lib.units import inch
from backend.core.config import settings

# Importer la KB pour récupérer le texte des questions
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
KB_PATH = os.path.join(BASE_DIR, "rag", "knowledge_base.json")
import json

# Charger la KB une seule fois
ALL_QUESTIONS = {}
try:
    with open(KB_PATH, encoding="utf-8") as f:
        data = json.load(f)
        for section in data.get("sections", []):
            for q in section["questions"]:
                ALL_QUESTIONS[q["id"]] = q["text"]
except Exception as e:
    logging.error(f"❌ Impossible de charger la KB pour le PDF : {e}")

# Config logs
logger = logging.getLogger(__name__)
os.makedirs(settings.REPORTS_DIR, exist_ok=True)

def generate_pdf(session_id: str, answers: dict, contexts: dict = None) -> str:
    """
    Génère un rapport PDF structuré, conforme à §4.6 et §1.2.1 du plan.
    
    Args:
        answers (dict): {"q001": "Landry", "q002": "34", ...}
        contexts (dict): Non utilisé dans le rapport final (conformité §3.3)
    """
    try:
        file_path = os.path.join(
            settings.REPORTS_DIR,
            f"rapport_{session_id}_{datetime.utcnow().strftime('%Y%m%d_%H%M%S')}.pdf"
        )
        c = canvas.Canvas(file_path, pagesize=A4)
        width, height = A4
        y = height - 50

        # ===== EN-TÊTE =====
        c.setFont("Helvetica-Bold", 18)
        c.drawString(50, y, "RAPPORT DE PRÉ-CONSULTATION – PALUDISME")
        y -= 30
        c.setFont("Helvetica", 12)
        c.drawString(50, y, f"Session ID : {session_id}")
        y -= 16
        c.drawString(50, y, f"Date : {datetime.utcnow().strftime('%d/%m/%Y à %H:%M UTC')}")
        y -= 30

        # ===== DONNÉES PATIENT (structurées) =====
        c.setFont("Helvetica-Bold", 14)
        c.drawString(50, y, "INFORMATIONS COLLECTÉES")
        y -= 20
        c.setFont("Helvetica", 11)

        # Regrouper par section pour lisibilité
        SECTIONS_ORDER = [
            ("identification", "Données démographiques"),
            ("symptomes_non_compliques", "Symptômes non compliqués"),
            ("symptomes_graves", "Symptômes graves (alerte OMS)"),
            ("groupes_a_risques", "Groupes vulnérables"),
            ("contexte_transmission", "Contexte de transmission"),
            ("cloture_conversation", "Clôture")
        ]

        for sec_id, sec_title in SECTIONS_ORDER:
            # Extraire les réponses de cette section
            sec_answers = []
            for q_id, answer in answers.items():
                q_text = ALL_QUESTIONS.get(q_id, f"[Question {q_id}]")
                if sec_id in q_id or (sec_id == "identification" and q_id in ["q001", "q002", "q003", "q004", "q005"]):
                    sec_answers.append((q_text, answer))
            
            if sec_answers:
                y -= 10
                if y < 100:
                    c.showPage()
                    y = height - 50
                c.setFont("Helvetica-Bold", 12)
                c.drawString(50, y, f"• {sec_title}")
                c.setFont("Helvetica", 11)
                y -= 18
                for q_text, answer in sec_answers:
                    if y < 100:
                        c.showPage()
                        y = height - 50
                    # Question
                    c.drawString(60, y, f"- {q_text}")
                    y -= 14
                    # Réponse
                    c.drawString(80, y, f"  → {answer}")
                    y -= 18

        # ===== AVERTISSEMENT ÉTHIQUE (§1.2.1) =====
        y -= 20
        if y < 100:
            c.showPage()
            y = height - 50
        c.setFont("Helvetica-Bold", 12)
        c.setFillColorRGB(0.8, 0, 0)  # Rouge foncé
        c.drawString(50, y, "⚠️ AVERTISSEMENT MÉDICAL")
        c.setFillColorRGB(0, 0, 0)
        y -= 18
        c.setFont("Helvetica", 10)
        warning_lines = [
            "Ce rapport a été généré automatiquement par un système d’aide à la collecte de données.",
            "Il ne constitue PAS un diagnostic médical et ne remplace en aucun cas l’avis",
            "d’un professionnel de santé qualifié.",
            "",
            "Source : Organisation Mondiale de la Santé (OMS) – Guide paludisme 2023"
        ]
        for line in warning_lines:
            if y < 60:
                c.showPage()
                y = height - 50
            c.drawString(50, y, line)
            y -= 14

        c.save()
        logger.info(f"✅ Rapport PDF structuré généré : {file_path}")
        return file_path

    except Exception as e:
        logger.exception(f"❌ Erreur génération PDF pour session {session_id}")
        raise