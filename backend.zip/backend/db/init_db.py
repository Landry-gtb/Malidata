# backend/db/init_db.py
from .database import Base, engine
from . import models

def init_db():
    """
    Crée toutes les tables définies dans models.py
    """
    print("🔄 Initialisation de la base de données...")
    Base.metadata.create_all(bind=engine)
    print("✅ Base de données prête !")
