from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import List, Optional, Dict, Any
import os
import logging

# Imports internes
from backend.utils.pdf_utils import generate_pdf
from backend.core.session_manager import session_manager
from backend.core.config import settings

# Config logger
logger = logging.getLogger(__name__)

router = APIRouter()


class ReportRequest(BaseModel):
    session_id: str
    contexts: Optional[List[Dict[str, Any]]] = None  # Nouveau champ optionnel


@router.post("/generate")
def generate_report(req: ReportRequest):
    session_id = req.session_id.strip()
    if not session_id:
        raise HTTPException(status_code=400, detail="Session ID invalide")

    logger.info(f"📝 Demande de génération de rapport pour la session: {session_id}")

    try:
        # Récupérer les réponses
        answers = session_manager.get_answers(session_id)
        if not answers:
            logger.warning(f"Aucune réponse trouvée pour session {session_id}")
            raise HTTPException(status_code=404, detail="Aucune réponse trouvée pour cette session")

        # Génération du PDF (avec ou sans contextes)
        file_path = generate_pdf(session_id, answers, req.contexts)

        # Vérifier que le fichier a bien été généré
        if not os.path.exists(file_path):
            logger.error(f"Échec de génération du PDF pour session {session_id}")
            raise HTTPException(status_code=500, detail="Erreur lors de la génération du rapport PDF")

        logger.info(f"✅ Rapport PDF généré : {file_path}")

        return {
            "session_id": session_id,
            "rapport_pdf": file_path
        }

    except HTTPException:
        raise
    except Exception as e:
        logger.exception(f"Erreur inattendue lors de la génération du rapport (session {session_id})")
        raise HTTPException(status_code=500, detail=f"Erreur interne: {str(e)}")
