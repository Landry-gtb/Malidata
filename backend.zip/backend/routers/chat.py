# backend/routers/chat.py
import os
import json
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from backend.core.session_manager import session_manager, r
from backend.core.language_detection import ensure_french
from backend.utils.pdf_utils import generate_pdf
from backend.llm.llm_service import humanize_question, _humanize_fallback, llm
from backend.rag.rag_service import vector_store

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
KB_PATH = os.path.join(BASE_DIR, "rag", "knowledge_base.json")

KNOWLEDGE_BASE = None
ALL_QUESTIONS = {}
SECTION_CONTEXTS = {}

if os.path.exists(KB_PATH):
    try:
        with open(KB_PATH, encoding="utf-8") as f:
            data = json.load(f)
            KNOWLEDGE_BASE = data.get("sections", [])
            for section in KNOWLEDGE_BASE:
                sec_id = section["id"]
                texts = [q["text"] for q in section["questions"]]
                SECTION_CONTEXTS[sec_id] = " ".join(texts)
                for q in section["questions"]:
                    q["section"] = sec_id
                    ALL_QUESTIONS[q["id"]] = q
        print(f"✅ KB chargée : {len(ALL_QUESTIONS)} questions")
    except Exception as e:
        print(f"[ERREUR] Chargement KB : {e}")

def get_next_question_id(covered_ids: set) -> str:
    if not ALL_QUESTIONS:
        return None
    sorted_questions = sorted(ALL_QUESTIONS.values(), key=lambda x: x["priority"])
    for q in sorted_questions:
        if q["id"] not in covered_ids:
            return q["id"]
    return None

def get_section_for_question(q_id: str) -> str:
    return ALL_QUESTIONS.get(q_id, {}).get("section", "default")

router = APIRouter()

class AnswerRequest(BaseModel):
    session_id: str
    answer: str

class EndSessionRequest(BaseModel):
    session_id: str

@router.post("/start_session")
def start_session():
    try:
        if not KNOWLEDGE_BASE:
            raise HTTPException(status_code=500, detail="Base de connaissances non chargée.")
        session_id = session_manager.create_session()
        first_id = get_next_question_id(set())
        if not first_id:
            raise HTTPException(status_code=500, detail="Aucune question disponible.")
        first_q = ALL_QUESTIONS[first_id]
        session_manager.set_session_state(session_id, {
            "covered": [first_id],
            "answers": {},
            "contexts": {}
        })
        return {
            "session_id": session_id,
            "first_question": {"text": first_q["text"], "id": first_id}
        }
    except HTTPException:
        raise
    except Exception as e:
        print(f"[ERROR] start_session: {e}")
        raise HTTPException(status_code=500, detail="Erreur interne.")

@router.post("/answer")
def answer(req: AnswerRequest):
    try:
        if not session_manager.session_active(req.session_id):
            raise HTTPException(status_code=409, detail="Session expirée.")
        if not ensure_french(req.answer):
            return {"question": {"text": "Merci de répondre en français.", "id": "lang"}}

        state = session_manager.get_session_state(req.session_id)
        if not state:
            raise HTTPException(status_code=500, detail="État corrompu.")

        current_id = state["covered"][-1]
        state["answers"][current_id] = req.answer

        next_id = get_next_question_id(set(state["covered"]))
        if not next_id:
            state["completed"] = True
            session_manager.set_session_state(req.session_id, state)
            return {"message": "Merci ! La collecte est terminée.", "completed": True}

        next_q = ALL_QUESTIONS[next_id]
        section = get_section_for_question(next_id)

        # Cache Redis pour les questions
        natural_q = None
        cached = r.get(f"question:{next_id}")
        if cached:
            natural_q = cached.decode('utf-8')
        else:
            if section == "identification":
                natural_q = _humanize_fallback(next_q["text"])
            else:
                rag_context = SECTION_CONTEXTS.get(section, "")
                natural_q = humanize_question(next_q["text"], state["answers"], rag_context)
            r.setex(f"question:{next_id}", 86400, natural_q.encode('utf-8'))

        # Clarification ciblée
        clarification = None
        if len(req.answer.strip()) > 10 and llm and vector_store:
            try:
                docs = vector_store.similarity_search(req.answer, k=1)
                rag_context = docs[0].page_content if docs else ""
                prompt = (
                    f"Contexte OMS : {rag_context[:300]}\n"
                    f"Réponse patient : {req.answer}\n"
                    f"→ Clarification courte en français (pas de diagnostic) :"
                )
                response = llm.invoke(prompt, timeout=5)
                clarification = response.content.strip()
            except Exception as e:
                print(f"[WARN] Clarification échouée : {e}")

        state["covered"].append(next_id)
        session_manager.set_session_state(req.session_id, state)

        return {
            "question": {"text": natural_q, "id": next_id},
            "clarification": clarification
        }

    except HTTPException:
        raise
    except Exception as e:
        print(f"[CRITICAL] Erreur non gérée dans /answer : {e}")
        next_id = get_next_question_id(set(state["covered"]))
        if next_id:
            next_q = ALL_QUESTIONS[next_id]
            natural_q = _humanize_fallback(next_q["text"])
            return {
                "question": {"text": natural_q, "id": next_id},
                "clarification": "⚠️ Le système a rencontré un ralentissement. Veuillez patienter."
            }
        else:
            return {"message": "Collecte terminée.", "completed": True}

@router.post("/end_session")
def end_session(req: EndSessionRequest):
    try:
        state = session_manager.get_session_state(req.session_id)
        if not state or not state.get("completed"):
            raise HTTPException(status_code=400, detail="Conversation non terminée.")
        file_path = generate_pdf(req.session_id, state["answers"], state["contexts"])
        session_manager.close_session(req.session_id)
        return {"message": "Session clôturée", "rapport_pdf": file_path}
    except HTTPException:
        raise
    except Exception as e:
        print(f"[ERROR] end_session: {e}")
        raise HTTPException(status_code=500, detail="Erreur interne.")