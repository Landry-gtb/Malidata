# backend/routers/rag.py
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
import json
import os

# Importer la config centralisée
from backend.core.config import settings

# ✅ Importer le service RAG compatible avec LangChain (pas gemini_client)
from backend.rag.rag_service import rag_search

router = APIRouter()

# Charger la knowledge base avec un chemin robuste
KNOWLEDGE_BASE = None
try:
    kb_path = settings.KNOWLEDGE_BASE_PATH
    if not os.path.exists(kb_path):
        raise FileNotFoundError(f"❌ Fichier knowledge_base.json introuvable à {kb_path}")

    with open(kb_path, encoding="utf-8") as f:
        KNOWLEDGE_BASE = json.load(f).get("sections", [])
    print(f"✅ Knowledge base chargée depuis : {kb_path} ({len(KNOWLEDGE_BASE)} sections)")
except Exception as e:
    print(f"[ERREUR] Impossible de charger la knowledge base : {e}")

# Modèle Pydantic pour la requête
class RAGRequest(BaseModel):
    question: str

@router.post("/query")
def rag_query(req: RAGRequest):
    if not req.question.strip():
        raise HTTPException(status_code=400, detail="La question ne peut pas être vide.")

    if KNOWLEDGE_BASE is None:
        raise HTTPException(status_code=500, detail="Knowledge base non chargée.")

    try:
        print(f"[DEBUG] Question reçue: {req.question}")
        print(f"[DEBUG] Nombre de sections KB: {len(KNOWLEDGE_BASE)}")

        # ✅ Utiliser rag_search au lieu de query_gemini
        result = rag_search(req.question)
        response_text = result.get("clarification", "Pas de réponse disponible.")

        print(f"[DEBUG] Réponse RAG: {response_text}")
        return {"answer": response_text}
    except Exception as e:
        print(f"[ERREUR] Exception dans rag_query: {e}")
        raise HTTPException(status_code=500, detail=f"Erreur RAG: {str(e)}")