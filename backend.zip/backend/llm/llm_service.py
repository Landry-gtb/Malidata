# backend/llm/llm_service.py
import os
import random

try:
    from langchain_google_genai import ChatGoogleGenerativeAI
    LLM_AVAILABLE = True
except ImportError:
    LLM_AVAILABLE = False

GEMINI_API_KEY = os.getenv("GEMINI_API_KEY", "").strip()
if not GEMINI_API_KEY:
    print("[WARN] GEMINI_API_KEY manquante")
    LLM_AVAILABLE = False

llm = None
if LLM_AVAILABLE:
    try:
        llm = ChatGoogleGenerativeAI(
            model="gemini-1.5-flash",
            api_key=GEMINI_API_KEY,
            temperature=0.3,
            max_output_tokens=64,
            timeout=10,  # ⏱️ Timeout natif (fonctionne mieux que asyncio)
        )
    except Exception as e:
        print(f"[WARN] LLM désactivé : {e}")
        LLM_AVAILABLE = False

def _humanize_fallback(question_text: str) -> str:
    q = question_text.strip().rstrip("?").rstrip(".")
    replacements = {
        "Quel est votre": "Pourriez-vous me dire votre",
        "Avez-vous": "Avez-vous ressenti",
        "Veuillez indiquer": "Pourriez-vous indiquer",
        "Depuis combien de jours": "Depuis combien de temps",
        "Où résidez-vous": "Dans quelle ville ou pays résidez-vous",
    }
    for old, new in replacements.items():
        if old in q:
            q = q.replace(old, new)
    starters = ["", "Merci de préciser : ", "Pour avancer, "]
    return f"{random.choice(starters)}{q} ?".replace("  ", " ")

def humanize_question(question_text: str, answers: dict, rag_context: str = "") -> str:
    prompt = f"Reformule naturellement en français : « {question_text} » →"
    if LLM_AVAILABLE and llm:
        try:
            response = llm.invoke(prompt)
            return response.content.strip()
        except Exception as e:
            print(f"[WARN] LLM échoué : {e}")
    return _humanize_fallback(question_text)