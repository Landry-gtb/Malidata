from langdetect import detect, DetectorFactory

# Pour rendre les résultats reproductibles
DetectorFactory.seed = 0  

# Liste de mots ou expressions typiquement français
FRENCH_KEYWORDS = [
    "oui", "non", "merci", "ans", "âge", "d'accord",
    "bonjour", "bonsoir", "salut", "j'ai", "je"
]

def ensure_french(answer: str) -> bool:
    """
    Vérifie si la réponse est en français.
    Améliorations :
    - Normalise les apostrophes (‘ → ')
    - Accepte automatiquement les réponses courtes ou numériques
    - Vérifie la présence de mots-clés français
    - Utilise langdetect pour les phrases plus longues
    """
    if not answer or not isinstance(answer, str):
        return False

    # Nettoyage et normalisation
    answer_norm = answer.strip().lower()
    answer_norm = answer_norm.replace("’", "'")  # apostrophe typographique

    # Si c'est une réponse très courte (ex: "34", "oui", "non")
    if len(answer_norm) < 5:
        return True

    # Si certains mots-clés français apparaissent, on accepte
    for kw in FRENCH_KEYWORDS:
        if kw in answer_norm:
            return True

    # Sinon on utilise langdetect
    try:
        return detect(answer_norm) == "fr"
    except:
        return False
