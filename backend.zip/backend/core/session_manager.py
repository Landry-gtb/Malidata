# backend/core/session_manager.py
import redis
import uuid
import json
import logging
from backend.core.config import settings

logger = logging.getLogger(__name__)

# Expose r avec decode_responses=False pour le cache binaire
try:
    r = redis.Redis.from_url(settings.REDIS_URL, decode_responses=False)
    r.ping()
    logger.info(f"✅ Connecté à Redis: {settings.REDIS_URL}")
except Exception as e:
    logger.error(f"❌ Redis indisponible: {e}")
    r = None

class SessionManager:
    def __init__(self, redis_client):
        self.r = redis_client

    def create_session(self):
        if not self.r:
            raise RuntimeError("Redis non disponible")
        session_id = str(uuid.uuid4())
        self.r.setex(f"session:{session_id}:active", 3600, "1")
        return session_id

    def session_active(self, session_id: str) -> bool:
        return bool(self.r and self.r.exists(f"session:{session_id}:active"))

    def close_session(self, session_id: str):
        if not self.r:
            return
        self.r.delete(f"session:{session_id}:active")

    def set_session_state(self, session_id: str, state: dict):
        if not self.r:
            raise RuntimeError("Redis non disponible")
        self.r.setex(f"session:{session_id}:state", 3600, json.dumps(state).encode('utf-8'))

    def get_session_state(self, session_id: str) -> dict:
        if not self.r:
            raise RuntimeError("Redis non disponible")
        state_bytes = self.r.get(f"session:{session_id}:state")
        if not state_bytes:
            return {"covered": [], "answers": {}, "contexts": {}}
        try:
            return json.loads(state_bytes.decode('utf-8'))
        except Exception:
            return {"covered": [], "answers": {}, "contexts": {}}

session_manager = SessionManager(r)