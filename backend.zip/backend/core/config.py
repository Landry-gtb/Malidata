import os
from dotenv import load_dotenv

load_dotenv()

class Settings:
    # Environnement
    APP_ENV = os.getenv("APP_ENV", "dev")
    SECRET_KEY = os.getenv("SECRET_KEY", "secret")

    # Base de données Postgres
    PG_HOST = os.getenv("PG_HOST", "localhost")
    PG_PORT = int(os.getenv("PG_PORT", 5432))
    PG_DB = os.getenv("PG_DB", os.getenv("POSTGRES_DB", "malidata"))
    PG_USER = os.getenv("PG_USER", os.getenv("POSTGRES_USER", "postgres"))
    PG_PASSWORD = os.getenv("PG_PASSWORD", os.getenv("POSTGRES_PASSWORD", "postgres"))

    # Redis
    REDIS_URL = os.getenv("REDIS_URL", "redis://localhost:6379/0")

    # Gemini (Google Generative AI)
    GEMINI_API_KEY = os.getenv("GEMINI_API_KEY")
    # 🔹 Correction : valeur par défaut stabilisée sur le modèle disponible
    GEMINI_MODEL = os.getenv("GEMINI_MODEL", "gemini-flash-latest")

    # Rapports PDF
    REPORTS_DIR = os.getenv("REPORTS_DIR", "./backend/reports")

    # Vector store
    VECTOR_STORE_PATH = os.getenv("VECTOR_STORE_PATH", "./backend/rag/vector_store")

    # Knowledge base JSON
    KNOWLEDGE_BASE_PATH = os.getenv("KNOWLEDGE_BASE_PATH", "./backend/rag/knowledge_base.json")

settings = Settings()
