import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

// ⚠️ Vite ne charge que les variables commençant par VITE_ dans import.meta.env
export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173, // Port par défaut de Vite
    proxy: {
      // Si tu veux que les appels à /api en local passent vers le backend
      "/api": {
        target: "http://localhost:8000",
        changeOrigin: true,
      },
    },
  },
});
