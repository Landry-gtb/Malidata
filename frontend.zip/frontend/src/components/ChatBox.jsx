import React, { useState, useRef, useEffect } from "react";
import { startSession, sendAnswer, endSession, downloadPDF } from "../api";

function ChatBox() {
  const [sessionId, setSessionId] = useState(null);
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(false);
  const [sessionEnded, setSessionEnded] = useState(false);
  const chatEndRef = useRef(null);

  // Auto scroll vers le bas quand un message arrive
  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  // -----------------------------
  // 1. Démarrer session
  // -----------------------------
  const handleStart = async () => {
    try {
      setError(null);
      const res = await startSession(); // appelle /api/chat/start_session
      setSessionId(res.session_id);
      setMessages([{ from: "bot", text: res.question.text }]);
      setSessionEnded(false);
    } catch (err) {
      setError("❌ Impossible de démarrer la session. Vérifiez le backend.");
    }
  };

  // -----------------------------
  // 2. Envoyer réponse
  // -----------------------------
  const handleAnswer = async () => {
    if (!input.trim()) return;
    setMessages((prev) => [...prev, { from: "user", text: input }]);
    setLoading(true);
    try {
      setError(null);
      const res = await sendAnswer(sessionId, input); // appelle /api/chat/answer

      if (res.question) {
        setMessages((prev) => [...prev, { from: "bot", text: res.question.text }]);
      } else if (res.message) {
        setMessages((prev) => [...prev, { from: "bot", text: res.message }]);
        setSessionEnded(true); // session terminée
      }
    } catch (err) {
      setError("⚠️ Erreur lors de l'envoi de la réponse.");
    }
    setInput("");
    setLoading(false);
  };

  // -----------------------------
  // 3. Clôturer session
  // -----------------------------
  const handleEnd = async () => {
    try {
      const res = await endSession(sessionId); // appelle /api/chat/end_session
      setMessages((prev) => [...prev, { from: "bot", text: res.message }]);
      setSessionEnded(true);
    } catch (err) {
      setError("⚠️ Impossible de clôturer la session.");
    }
  };

  // -----------------------------
  // 4. Télécharger PDF
  // -----------------------------
  const handleDownloadPDF = async () => {
    try {
      const blob = await downloadPDF(sessionId); // appelle /api/chat/download_pdf
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `rapport_session_${sessionId}.pdf`;
      a.click();
      a.remove();

      // Reset après téléchargement
      setSessionId(null);
      setMessages([]);
      setSessionEnded(false);
    } catch (err) {
      setError("⚠️ Erreur lors du téléchargement du PDF.");
    }
  };

  return (
    <div style={{ maxWidth: 600, margin: "0 auto", fontFamily: "Arial" }}>
      <h1>💬 Malidata Chatbot</h1>

      {!sessionId && !sessionEnded && (
        <button onClick={handleStart}>▶️ Lancer Session</button>
      )}
      {sessionId && !sessionEnded && (
        <button onClick={handleEnd}>⏹️ Clôturer Session</button>
      )}

      {error && (
        <div style={{ color: "red", marginTop: 10 }}>{error}</div>
      )}

      <div
        style={{
          border: "1px solid #ccc",
          padding: 10,
          height: 400,
          overflowY: "auto",
          marginTop: 20,
          background: "#fafafa",
        }}
      >
        {messages.map((m, i) => (
          <div
            key={i}
            style={{
              textAlign: m.from === "user" ? "right" : "left",
              margin: "5px 0",
            }}
          >
            <span
              style={{
                display: "inline-block",
                padding: "8px 12px",
                borderRadius: 10,
                background: m.from === "user" ? "#daf1da" : "#eee",
              }}
            >
              {m.text}
            </span>
          </div>
        ))}
        <div ref={chatEndRef} />
      </div>

      {sessionId && !sessionEnded && (
        <div style={{ marginTop: 10, display: "flex", gap: "5px" }}>
          <input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Votre réponse..."
            style={{ flex: 1, padding: "8px" }}
          />
          <button
            onClick={handleAnswer}
            disabled={!input.trim() || loading}
          >
            {loading ? "⏳" : "Envoyer"}
          </button>
        </div>
      )}

      {sessionEnded && (
        <div style={{ marginTop: 20 }}>
          <button onClick={handleDownloadPDF}>📥 Télécharger Rapport PDF</button>
        </div>
      )}
    </div>
  );
}

export default ChatBox;
