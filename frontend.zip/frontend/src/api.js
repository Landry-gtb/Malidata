// frontend/src/api.js
import axios from "axios";

const baseURL =
  import.meta.env.VITE_API_URL && import.meta.env.VITE_API_URL !== ""
    ? `${import.meta.env.VITE_API_URL}/api`
    : "/api";

const API = axios.create({
  baseURL,
  timeout: 15000,
});

// Interceptors (inchangés)
API.interceptors.request.use(
  (config) => config,
  (error) => Promise.reject(error)
);

API.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.code === "ECONNABORTED") {
      return Promise.reject({
        message: "⏳ Timeout serveur, réessayez plus tard.",
      });
    }
    if (error.response) {
      return Promise.reject({
        status: error.response.status,
        message:
          error.response.data?.detail ||
          "Erreur lors de la communication avec le serveur.",
      });
    }
    return Promise.reject({ message: error.message });
  }
);

// ✅ CORRECTION : Ajout de {} pour éviter l'erreur 422
export const startSession = async () => {
  const response = await API.post("/chat/start_session", {}); // ← Body vide mais valide
  return response.data;
};

export const sendAnswer = async (session_id, answer) => {
  const response = await API.post("/chat/answer", { session_id, answer });
  return response.data;
};

export const endSession = async (session_id) => {
  const response = await API.post("/chat/end_session", { session_id }); // ← Déjà correct
  return response.data;
};

export const downloadPDF = async (session_id) => {
  const response = await API.post("/reports/generate", { session_id }, {
    responseType: "blob",
  });
  return response.data;
};

export default API;