// frontend/src/App.jsx
import React, { useState, useEffect } from "react";
import "./App.css";
import { startSession, sendAnswer, endSession, downloadPDF } from "./api";

function App() {
  const [sessionId, setSessionId] = useState(null);
  const [currentQuestion, setCurrentQuestion] = useState(null);
  const [clarification, setClarification] = useState(null);
  const [answers, setAnswers] = useState({});
  const [isCompleted, setIsCompleted] = useState(false);
  const [userInput, setUserInput] = useState("");
  const [error, setError] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [showConsent, setShowConsent] = useState(true);

  const handleAcceptConsent = async () => {
    if (isLoading) return;
    setIsLoading(true);
    setError(null);
    try {
      const data = await startSession();
      if (data?.session_id && data?.first_question) {
        setSessionId(data.session_id);
        setCurrentQuestion(data.first_question);
        setShowConsent(false);
      } else {
        throw new Error("Réponse invalide du serveur");
      }
    } catch (err) {
      setError("Impossible de démarrer la session. Veuillez réessayer.");
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSend = async () => {
    const trimmed = userInput.trim();
    if (!trimmed || !sessionId) return;

    setIsLoading(true);
    setError(null);

    try {
      const currentQ = currentQuestion?.text || "Question précédente";
      setAnswers((prev) => ({ ...prev, [currentQ]: trimmed }));

      const response = await sendAnswer(sessionId, trimmed);

      if (response.completed) {
        setIsCompleted(true);
      } else if (response.question?.text) {
        setCurrentQuestion(response.question);
        setClarification(response.clarification || null);
      } else {
        setError("Le serveur n’a pas renvoyé de prochaine question.");
      }

      setUserInput("");
    } catch (err) {
      setError("Erreur lors de l’envoi de votre réponse. Veuillez réessayer.");
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  const handleDownloadPDF = async () => {
    if (!sessionId) return;
    setIsLoading(true);
    try {
      const pdfBlob = await downloadPDF(sessionId);
      const url = window.URL.createObjectURL(pdfBlob);
      const link = document.createElement("a");
      link.href = url;
      link.download = `rapport_malaria_${sessionId}.pdf`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      window.URL.revokeObjectURL(url);
    } catch (err) {
      setError("Erreur lors du téléchargement du rapport.");
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  const handleKeyPress = (e) => {
    if (e.key === "Enter" && !isLoading) handleSend();
  };

  if (showConsent) {
    return (
      <div className="app">
        <header>
          <h1>🩺 Malidata — Pré-consultation Malaria</h1>
        </header>
        <main className="consent">
          <div className="warning">
            ⚠️ <strong>Ce chatbot ne diagnostique pas.</strong> Il collecte des informations pour aider votre médecin.
          </div>
          <p>
            Vos données seront <strong>anonymisées</strong>, sécurisées et utilisées uniquement à des fins médicales, conformément au RGPD.
          </p>
          <button onClick={handleAcceptConsent} disabled={isLoading} className="btn-primary">
            {isLoading ? "Chargement..." : "✅ J’accepte et je commence"}
          </button>
          {error && <p className="error">{error}</p>}
        </main>
        <footer><p>© 2025 — Projet Malidata | Aucun diagnostic automatisé</p></footer>
      </div>
    );
  }

  if (isCompleted) {
    return (
      <div className="app">
        <header>
          <h1>🩺 Malidata — Pré-consultation Malaria</h1>
        </header>
        <main className="completion">
          <h2>✅ Collecte terminée</h2>
          <p>Vos réponses ont été enregistrées avec succès.</p>
          <p><em>Merci de votre participation. Ce rapport sera transmis à votre médecin.</em></p>
          <button onClick={handleDownloadPDF} disabled={isLoading} className="btn-download">
            {isLoading ? "Génération du rapport..." : "📄 Télécharger Rapport PDF"}
          </button>
        </main>
        <footer><p>© 2025 — Projet Malidata | Données sécurisées • Aucun diagnostic</p></footer>
      </div>
    );
  }

  return (
    <div className="app">
      <header>
        <h1>🩺 Malidata — Pré-consultation Malaria</h1>
        <p className="disclaimer">
          ⚠️ Ce chatbot ne diagnostique pas. Il collecte des données pour aider votre médecin.
        </p>
      </header>

      <main className="chat-container">
        <div className="chat-history">
          {Object.entries(answers).map(([q, a], idx) => (
            <div key={idx} className="exchange">
              <div className="bot-message"><strong>Bot :</strong> {q}</div>
              <div className="user-message"><strong>Vous :</strong> {a}</div>
            </div>
          ))}
        </div>

        {currentQuestion && (
          <div className="current-question">
            <p><strong>Bot :</strong> {currentQuestion.text}</p>
            {clarification && (
              <div className="clarification">{clarification}</div>
            )}
            <input
              value={userInput}
              onChange={(e) => setUserInput(e.target.value)}
              onKeyPress={handleKeyPress}
              placeholder="Tapez votre réponse..."
              disabled={isLoading}
              autoFocus
            />
            <button onClick={handleSend} disabled={!userInput.trim() || isLoading} className="btn-send">
              Envoyer
            </button>
          </div>
        )}

        {error && <p className="error">{error}</p>}
      </main>

      <footer>
        <p>© 2025 — Projet Malidata | Données sécurisées • Aucun diagnostic</p>
      </footer>
    </div>
  );
}

export default App;